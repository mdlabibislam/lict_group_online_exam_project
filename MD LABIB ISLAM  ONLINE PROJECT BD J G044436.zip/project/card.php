<?php
session_start();


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" href="css/pop.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/jquery-ui.js"></script>
<style media="screen">
      h1{
        text-align: center;
        font-family: sans-serif;
      }
      table {
        font-family: sans-serif;
        border-collapse: collapse;
        border-spacing: 0;
        width: 80%;
        border: 1px solid #ddd;
      }
      th, td {
        text-align: left;
        padding: 16px;
      }
      tr:nth-child(even) {
        background-color: #f2f2f2
      }
    </style>



</head>
<body>
<div class="CPE">
	<h2>HERE YOUR ADMIT CARD</h2>
</div>
<?php

$ip="localhost";
$user="root";
$password="";
$dbname="result";
$dop=0;
$con=mysqli_connect($ip,$user,$password,$dbname);
if (!mysqli_connect_error()) {
	echo "";
}else{
	echo "database not coonect";
} 

 $sql_read = "SELECT `id` FROM MASUM";
      $sl_no = 0;
      $result = mysqli_query($con,$sql_read);
      while ($row = mysqli_fetch_array($result)) {
        $sl_no = $sl_no + 1;
      }
      $last_id = $sl_no;
      $last_id = $last_id + 1;
      $date = date('d-m-Y');
      $day=date("d",strtotime($date));
      $month=date("m",strtotime($date));
      $year=date("Y",strtotime($date));
      $whole_date=$year.$month.$day;
      $unique_id=$whole_date.$last_id;
      // Insert the Unique ID into the Database in its specific column of the table
      $sql_write = "INSERT INTO MASUM (`uniqueid`) VALUES('{$unique_id}')";
      if(!mysqli_query($con, $sql_write)){
        echo "<script>alert('ERROR : Unique ID Generation Failed');</script>";
      }

    $sql_read = "SELECT * FROM MASUM";
    $result = mysqli_query($con, $sql_read);
    if($result){
    $sl_no = 0;
    
      $sl_no = $sl_no + 1;

      $_SESSION['ROLL']=$unique_id;
      echo "<tr>";
      
      echo "</tr>";
    echo "</table>";
 
    }
    














echo "<table>";
echo "<tr>";
echo "<td>Roll number</td>"."<td>".$_SESSION['ROLL']."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>Name</td>"."<td>". $_SESSION['name']."</td>"."</br>";
echo "</tr>";
echo "<tr>";
echo "<td>Father's name</td>"."<td>". $_SESSION['father']."</td>"."</br>";
echo "</tr>";
echo "<tr>";
echo "<td>mothers's name</td>"."<td>". $_SESSION['mother']."</td>"."</br>";
echo "</tr>";
echo "<tr>";
echo "<td>subject</td>"."<td>". $_SESSION['subject']."</td>"."</br>";
echo "</tr>";
echo "<tr>";
echo "<td>gender</td>"."<td>". $_SESSION['gender']."</td>";
echo "</tr>";
echo "<tr>";
echo "<td>password</td>"."<td>".$_SESSION['gopon']."</td>";
echo "</tr>";

?>
<div class="ent">
<a href="back.php">for exam clik</a>
<div class="print">
<a href="#" onclick="window.print();return false;" title="Click to print this page">print</a>
</div>
</div>
</body>
</html>