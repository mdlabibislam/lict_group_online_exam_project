<?php

session_start();


?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Table using CSS</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/pop.css">
    <style media="screen">
      h1{
        text-align: center;
        font-family: sans-serif;
      }
      table {
        font-family: sans-serif;
        border-collapse: collapse;
        border-spacing: 0;
        width: 80%;
        border: 1px solid #ddd;
      }
      th, td {
        text-align: left;
        padding: 16px;
      }
      tr:nth-child(even) {
        background-color: #f2f2f2
      }
    </style>
  </head>
  <body>
  <div class="tom">
  <h2>HERE YOUR MARKS</h2>
  </div>
    <div class="tines">
		<?php
		require_once('db.php');

  $a=$_SESSION['father'];
   $b=$_SESSION['mother'];
   $c=$_SESSION['name'];
  $d=$_SESSION['subject']; 
   $e=$_SESSION['gender'];


		$response=mysqli_query($con,"SELECT  `qid`,`question`,`correctans` from ques");


			 $i=1;
			 $right_answer=0;
			 $wrong_answer=0;
			 $unanswered=0;
			 while($result=mysqli_fetch_array($response)){
			       if($result['correctans']==$_POST["$i"]){
				       $right_answer++;
				   }else if($_POST["$i"]==10){
				       $unanswered++;
				   }
				   else{
				       $wrong_answer++;
				   }
				   $i++;
			 }

			 echo "<table>";
echo "<tr>";
echo "<th>marks</th>";
echo "<th>wronganswered</th>";
echo "<th>Unanswered</th>";
echo "<th>name</th>";
echo "<th>Father's name</th>";
echo "<th>mothers's name</th>";
echo "<th>subject</th>";
echo "<th>gender</th>";
echo "</tr>";
echo "<tr>";
echo "<td>$right_answer</td>";
echo "<td>$wrong_answer</td>";
echo "<td>$unanswered</td>";
echo "<td>$c</td>";
echo "<td>$a</td>";
echo "<td>$b</td>";
echo "<td>$d</td>";
echo "<td>$e</td>";
echo "</tr>";
 echo "</table>";

		?>


</div>

<div class="print">
<a href="#" onclick="window.print();return false;" title="Click to print this page">print</a>
</div>

<div class="ent">
<a href="index.php">back</a>
</div>
  </body>
</html>
