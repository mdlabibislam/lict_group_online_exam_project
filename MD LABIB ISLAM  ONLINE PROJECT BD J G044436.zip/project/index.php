
<?php
require ('index.html');

?>



